package com.hushly.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import android.content.res.ColorStateList
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.materialswitch.MaterialSwitch

class MainActivity : AppCompatActivity() {

    private val handler = Handler(Looper.getMainLooper())
    private val listener: () -> Unit = { refresh() }
    private val ticker = object : Runnable {
        override fun run() {
            refreshStatus()
            handler.postDelayed(this, 1000)
        }
    }

    private lateinit var tvNow: TextView
    private lateinit var tvSub: TextView
    private lateinit var btnPlay: TextView
    private lateinit var tvTimerVal: TextView
    private lateinit var tvDndSub: TextView
    private lateinit var swDnd: MaterialSwitch
    private lateinit var mixRow: LinearLayout
    private val circles = arrayOfNulls<TextView>(Player.count)
    private val seeks = arrayOfNulls<SeekBar>(Player.count)
    private var updating = false
    private var appliedAccent = ""
    private var askedNotif = false

    private val notifPerm =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { startPlay() }

    override fun onCreate(savedInstanceState: Bundle?) {
        Appearance.apply(this)
        super.onCreate(savedInstanceState)
        appliedAccent = Prefs.accent(this)
        Player.init(this)
        buildUi()
        refresh()
    }

    override fun onResume() {
        super.onResume()
        if (appliedAccent != Prefs.accent(this)) {
            recreate()
            return
        }
        if (Prefs.dndOn(this) && !Dnd.hasAccess(this)) {
            Prefs.sp(this).edit().putBoolean("dnd_on", false).apply()
        }
        Player.addListener(listener)
        refresh()
        handler.post(ticker)
    }

    override fun onPause() {
        super.onPause()
        Player.removeListener(listener)
        handler.removeCallbacks(ticker)
    }

    // ------------------------------------------------------------------ UI

    private fun dp(v: Int) = Ui.dp(this, v)

    private fun divider(startDp: Int): View {
        val d = View(this)
        d.setBackgroundColor(Ui.outline(this))
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1)
        lp.marginStart = dp(startDp)
        d.layoutParams = lp
        return d
    }

    private fun card(): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.setBackgroundResource(R.drawable.bg_card)
        c.clipToOutline = true
        return c
    }

    private fun sectionTitle(s: String): TextView {
        val t = Ui.label(this, s.uppercase(), 12.5f, Ui.secondary(this), true)
        t.letterSpacing = 0.04f
        t.setPadding(dp(16), dp(26), dp(16), dp(8))
        return t
    }

    private fun circleButton(text: String, onClick: () -> Unit): TextView {
        val b = TextView(this)
        b.text = text
        b.textSize = 20f
        b.gravity = Gravity.CENTER
        b.setTextColor(Ui.text(this))
        b.setBackgroundResource(R.drawable.bg_circle_btn)
        val lp = LinearLayout.LayoutParams(dp(46), dp(46))
        lp.marginStart = dp(10)
        b.layoutParams = lp
        b.setOnClickListener { Ui.tap(it); onClick() }
        return b
    }

    private fun listRow(title: String, sub: TextView?, trailing: View, onClick: (() -> Unit)?): LinearLayout {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(20), dp(14), dp(20), dp(14))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.addView(Ui.label(this, title, 17f, Ui.text(this)))
        if (sub != null) col.addView(sub)
        row.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(trailing)
        if (onClick != null) {
            val tv = android.util.TypedValue()
            theme.resolveAttribute(android.R.attr.selectableItemBackground, tv, true)
            row.setBackgroundResource(tv.resourceId)
            row.setOnClickListener { Ui.tap(it); onClick() }
        }
        return row
    }

    private fun buildUi() {
        val scroll = ScrollView(this)
        scroll.isFillViewport = true
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(16), dp(10), dp(16), dp(32))
        scroll.addView(root)

        // intestazione
        val header = LinearLayout(this)
        header.gravity = Gravity.CENTER_VERTICAL
        header.setPadding(dp(4), dp(6), 0, dp(10))
        val title = Ui.label(this, getString(R.string.app_name), 34f, Ui.text(this), true)
        header.addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        header.addView(circleButton("🌙") { openNight() })
        header.addView(circleButton("⚙️") { startActivity(Intent(this, SettingsActivity::class.java)) })
        root.addView(header)

        // scheda principale
        val hero = card()
        val top = LinearLayout(this)
        top.gravity = Gravity.CENTER_VERTICAL
        top.setPadding(dp(20), dp(20), dp(20), dp(18))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        tvNow = Ui.label(this, "", 21f, Ui.text(this), true)
        tvSub = Ui.label(this, "", 14f, Ui.secondary(this))
        tvSub.setPadding(0, dp(4), 0, 0)
        col.addView(tvNow)
        col.addView(tvSub)
        top.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        btnPlay = TextView(this)
        btnPlay.textSize = 24f
        btnPlay.gravity = Gravity.CENTER
        btnPlay.setTextColor(Ui.onPrimary(this))
        btnPlay.background = Ui.ovalBg(Ui.primary(this))
        val plp = LinearLayout.LayoutParams(dp(68), dp(68))
        plp.marginStart = dp(12)
        top.addView(btnPlay, plp)
        btnPlay.setOnClickListener { Ui.tap(it); togglePlay() }
        hero.addView(top)
        hero.addView(divider(20))

        tvTimerVal = Ui.label(this, "", 16f, Ui.primary(this), true)
        hero.addView(listRow(getString(R.string.main_timer), null, tvTimerVal) { showTimerSheet() })
        hero.addView(divider(20))

        tvDndSub = Ui.label(this, "", 13f, Ui.secondary(this))
        swDnd = MaterialSwitch(this)
        val dndRow = listRow(getString(R.string.main_dnd), tvDndSub, swDnd, null)
        swDnd.setOnClickListener { onDndToggle() }
        hero.addView(dndRow)
        hero.addView(divider(20))

        val chev = Ui.label(this, "›", 26f, Ui.secondary(this))
        hero.addView(listRow(getString(R.string.night_screen), null, chev) { openNight() })
        root.addView(hero)

        // suoni
        root.addView(sectionTitle(getString(R.string.main_sounds)))
        val sounds = card()
        for ((i, s) in Sounds.all.withIndex()) {
            if (i > 0) sounds.addView(divider(78))
            val row = LinearLayout(this)
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(dp(16), dp(10), dp(20), dp(10))
            val circ = TextView(this)
            circ.text = s.emoji
            circ.textSize = 22f
            circ.gravity = Gravity.CENTER
            row.addView(circ, LinearLayout.LayoutParams(dp(46), dp(46)))
            circles[i] = circ
            circ.setOnClickListener {
                Ui.tap(it)
                val cur = Player.levels[i]
                Player.setLevel(this, i, if (cur > 0.02f) 0f else Prefs.lastLevel(this, s.id))
            }
            val c2 = LinearLayout(this)
            c2.orientation = LinearLayout.VERTICAL
            c2.addView(Ui.label(this, getString(s.nameRes), 16f, Ui.text(this)))
            val sb = SeekBar(this)
            sb.max = 100
            sb.progressTintList = ColorStateList.valueOf(s.color)
            sb.thumbTintList = ColorStateList.valueOf(s.color)
            sb.progressBackgroundTintList = ColorStateList.valueOf(Ui.outline(this))
            sb.setPadding(dp(4), dp(6), dp(4), 0)
            sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(bar: SeekBar, p: Int, fromUser: Boolean) {
                    if (!fromUser || updating) return
                    Player.setLevel(this@MainActivity, i, p / 100f)
                }
                override fun onStartTrackingTouch(bar: SeekBar) { Ui.tick(bar) }
                override fun onStopTrackingTouch(bar: SeekBar) {}
            })
            seeks[i] = sb
            c2.addView(sb, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            val clp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            clp.marginStart = dp(14)
            row.addView(c2, clp)
            sounds.addView(row)
        }
        root.addView(sounds)

        // mix
        val mixHead = LinearLayout(this)
        mixHead.gravity = Gravity.CENTER_VERTICAL
        val mt = sectionTitle(getString(R.string.main_mixes))
        mixHead.addView(mt, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val save = Ui.label(this, getString(R.string.main_save_mix), 14f, Ui.primary(this), true)
        save.setPadding(dp(16), dp(26), dp(16), dp(8))
        save.setOnClickListener { Ui.tap(it); saveMixDialog() }
        mixHead.addView(save)
        root.addView(mixHead)
        val hs = HorizontalScrollView(this)
        hs.isHorizontalScrollBarEnabled = false
        mixRow = LinearLayout(this)
        hs.addView(mixRow)
        root.addView(hs)
        rebuildMixes()

        setContentView(scroll)
    }

    // ------------------------------------------------------------------ stato

    private fun refresh() {
        val playing = Player.isPlaying()
        val ids = Player.activeIds()
        tvNow.text = if (ids.isEmpty()) getString(R.string.main_nothing)
        else ids.joinToString(" + ") { getString(Sounds.all[Sounds.indexOf(it)].nameRes) }
        btnPlay.text = if (playing) "■" else "▶"
        tvTimerVal.text = Ui.fmtMinutes(this, Prefs.timerMin(this))
        refreshStatus()

        val timerOn = Prefs.timerMin(this) > 0
        tvDndSub.text = getString(if (timerOn) R.string.main_dnd_sub else R.string.main_dnd_need_timer)
        swDnd.isChecked = Prefs.dndOn(this) && Dnd.hasAccess(this)
        swDnd.isEnabled = timerOn

        updating = true
        for (i in 0 until Player.count) {
            val lv = Player.levels[i]
            val s = Sounds.all[i]
            val active = lv > 0.02f
            val col = if (active) (s.color and 0x00FFFFFF) or 0x59000000 else Ui.surfaceVariant(this)
            circles[i]?.background = Ui.ovalBg(col)
            circles[i]?.alpha = if (active) 1f else 0.7f
            val sb = seeks[i]
            if (sb != null && sb.progress != (lv * 100).toInt()) sb.progress = (lv * 100).toInt()
        }
        updating = false
    }

    private fun refreshStatus() {
        val rem = Player.remainingMs()
        tvSub.text = when {
            Player.isPlaying() && rem >= 0 -> getString(R.string.timer_remaining, Ui.fmtCountdown(rem))
            Player.isPlaying() -> getString(R.string.main_playing)
            else -> getString(R.string.main_ready)
        }
    }

    // ------------------------------------------------------------------ azioni

    private fun togglePlay() {
        if (Player.isPlaying()) {
            PlayerService.stop(this)
            return
        }
        if (Build.VERSION.SDK_INT >= 33 && !askedNotif &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            askedNotif = true
            notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            startPlay()
        }
    }

    private fun startPlay() {
        PlayerService.play(this)
        if (Prefs.nightAuto(this) && Prefs.timerMin(this) > 0) openNight()
    }

    private fun openNight() {
        startActivity(Intent(this, SleepActivity::class.java))
    }

    private fun onDndToggle() {
        if (swDnd.isChecked) {
            if (Dnd.hasAccess(this)) {
                Prefs.sp(this).edit().putBoolean("dnd_on", true).apply()
                Player.notifyChanged()
            } else {
                swDnd.isChecked = false
                MaterialAlertDialogBuilder(this)
                    .setTitle(R.string.main_dnd_perm_title)
                    .setMessage(R.string.main_dnd_perm_msg)
                    .setPositiveButton(R.string.btn_open_settings) { _, _ ->
                        Prefs.sp(this).edit().putBoolean("dnd_on", true).apply()
                        startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
                    }
                    .setNegativeButton(R.string.btn_cancel, null)
                    .show()
            }
        } else {
            Prefs.sp(this).edit().putBoolean("dnd_on", false).apply()
            Player.notifyChanged()
        }
    }

    private fun showTimerSheet() {
        val sheet = BottomSheetDialog(this)
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(0, dp(8), 0, dp(20))
        box.addView(Ui.label(this, getString(R.string.timer_title), 20f, Ui.text(this), true).also {
            it.setPadding(dp(24), dp(12), dp(24), dp(10))
        })
        val cur = Prefs.timerMin(this)
        val opts = listOf(0, 15, 30, 45, 60, 90, 120, 180)
        for (m in opts) {
            val check = Ui.label(this, if (m == cur) "✓" else "", 20f, Ui.primary(this), true)
            val row = listRow(Ui.fmtMinutes(this, m), null, check) {
                Player.setTimer(this, m)
                sheet.dismiss()
            }
            box.addView(row)
        }
        val custom = listRow(getString(R.string.timer_custom), null,
            Ui.label(this, if (cur !in opts) "✓" else "", 20f, Ui.primary(this), true)) {
            sheet.dismiss()
            customTimerDialog()
        }
        box.addView(custom)
        sheet.setContentView(box)
        sheet.show()
    }

    private fun customTimerDialog() {
        val et = EditText(this)
        et.inputType = InputType.TYPE_CLASS_NUMBER
        et.hint = getString(R.string.timer_custom_hint)
        val wrap = LinearLayout(this)
        wrap.setPadding(dp(24), dp(8), dp(24), 0)
        wrap.addView(et, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.timer_title)
            .setView(wrap)
            .setPositiveButton(R.string.btn_ok) { _, _ ->
                val m = et.text.toString().toIntOrNull()
                if (m != null && m in 1..720) Player.setTimer(this, m)
            }
            .setNegativeButton(R.string.btn_cancel, null)
            .show()
    }

    // ------------------------------------------------------------------ mix

    private class Preset(val nameRes: Int, val levels: Map<String, Float>)

    private val presets = listOf(
        Preset(R.string.mix_rainroof, mapOf("rain" to 0.7f, "wind" to 0.2f)),
        Preset(R.string.mix_storm, mapOf("storm" to 0.6f, "brown" to 0.25f)),
        Preset(R.string.mix_beach, mapOf("ocean" to 0.7f, "wind" to 0.15f)),
        Preset(R.string.mix_forest, mapOf("stream" to 0.55f, "wind" to 0.2f, "pink" to 0.1f)),
        Preset(R.string.mix_hearth, mapOf("fire" to 0.6f, "rain" to 0.25f))
    )

    private fun chip(text: String): TextView {
        val t = Ui.label(this, text, 14.5f, Ui.text(this))
        t.setPadding(dp(16), dp(11), dp(16), dp(11))
        t.background = Ui.roundBg(this, Ui.surface(this), 20)
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.marginEnd = dp(8)
        t.layoutParams = lp
        return t
    }

    private fun rebuildMixes() {
        mixRow.removeAllViews()
        for (p in presets) {
            val c = chip(getString(p.nameRes))
            c.setOnClickListener { Ui.tap(it); Player.applyMix(this, p.levels) }
            mixRow.addView(c)
        }
        val mixes = Prefs.mixes(this)
        for ((idx, m) in mixes.withIndex()) {
            val c = chip("★ " + m.name)
            c.setOnClickListener { Ui.tap(it); Player.applyMix(this, m.levels) }
            c.setOnLongClickListener {
                MaterialAlertDialogBuilder(this)
                    .setTitle(getString(R.string.mix_delete_title, m.name))
                    .setPositiveButton(R.string.btn_delete) { _, _ ->
                        val list = Prefs.mixes(this)
                        if (idx < list.size) list.removeAt(idx)
                        Prefs.saveMixes(this, list)
                        rebuildMixes()
                    }
                    .setNegativeButton(R.string.btn_cancel, null)
                    .show()
                true
            }
            mixRow.addView(c)
        }
    }

    private fun saveMixDialog() {
        if (!Player.anyActive()) {
            Toast.makeText(this, R.string.mix_empty_toast, Toast.LENGTH_SHORT).show()
            return
        }
        val et = EditText(this)
        et.hint = getString(R.string.mix_name_hint)
        et.setSingleLine()
        val wrap = LinearLayout(this)
        wrap.setPadding(dp(24), dp(8), dp(24), 0)
        wrap.addView(et, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.mix_name_title)
            .setView(wrap)
            .setPositiveButton(R.string.btn_save) { _, _ ->
                val name = et.text.toString().trim().ifEmpty { getString(R.string.mix_default_name) }
                val lv = mutableMapOf<String, Float>()
                for (i in 0 until Player.count) {
                    if (Player.levels[i] > 0.02f) lv[Sounds.all[i].id] = Player.levels[i]
                }
                val list = Prefs.mixes(this)
                list.add(Mix(name, lv))
                Prefs.saveMixes(this, list)
                rebuildMixes()
                Toast.makeText(this, R.string.mix_saved, Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton(R.string.btn_cancel, null)
            .show()
    }
}
