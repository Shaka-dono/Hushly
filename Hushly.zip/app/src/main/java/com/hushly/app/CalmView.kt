package com.hushly.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.view.View
import java.util.Random
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/**
 * Animazione "di pace": grandi aloni di luce che fluttuano lentamente, un cerchio che respira
 * (10 secondi per ciclo) e poche stelle che brillano piano. Sfondo nero (OLED = pixel spenti).
 */
class CalmView(context: Context) : View(context) {

    private class Orb(val sx: Double, val sy: Double, val px: Double, val py: Double, val size: Double)

    private val orbs = listOf(
        Orb(0.071, 0.053, 0.0, 1.3, 0.62),
        Orb(0.047, 0.083, 2.1, 0.4, 0.55),
        Orb(0.061, 0.039, 4.0, 2.7, 0.70),
        Orb(0.033, 0.067, 5.2, 3.9, 0.50)
    )
    private var shaders = arrayOfNulls<RadialGradient>(4)
    private var colors = intArrayOf(Color.parseColor("#6C74FF"), Color.parseColor("#5EEAD4"), Color.parseColor("#C4A1FF"))
    private val orbPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val starPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private var glowShader: RadialGradient? = null

    private val rnd = Random(11)
    private val starX = FloatArray(30) { rnd.nextFloat() }
    private val starY = FloatArray(30) { rnd.nextFloat() * 0.9f }
    private val starF = FloatArray(30) { 0.25f + rnd.nextFloat() * 0.5f }
    private val starP = FloatArray(30) { rnd.nextFloat() * 6.28f }
    private val starR = FloatArray(30) { 0.8f + rnd.nextFloat() * 1.1f }

    var animated = true
        set(v) { field = v; invalidate() }
    private var running = false
    private val t0 = System.nanoTime()

    /** Intensità generale (0..1): bassa per non disturbare il sonno. */
    var intensity = 0.55f

    fun setPalette(list: List<Int>) {
        val base = if (list.isEmpty()) listOf(Color.parseColor("#6C74FF"), Color.parseColor("#5EEAD4"), Color.parseColor("#C4A1FF")) else list
        colors = IntArray(3) { base[it % base.size] }
        buildShaders()
        invalidate()
    }

    private fun buildShaders() {
        for (i in 0 until 4) {
            val c = colors[i % colors.size]
            val center = Color.argb(150, Color.red(c), Color.green(c), Color.blue(c))
            val mid = Color.argb(50, Color.red(c), Color.green(c), Color.blue(c))
            val edge = Color.argb(0, Color.red(c), Color.green(c), Color.blue(c))
            shaders[i] = RadialGradient(0f, 0f, 1f, intArrayOf(center, mid, edge), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
        }
        val g = colors[0]
        glowShader = RadialGradient(
            0f, 0f, 1f,
            intArrayOf(Color.argb(70, Color.red(g), Color.green(g), Color.blue(g)), Color.argb(0, Color.red(g), Color.green(g), Color.blue(g))),
            floatArrayOf(0f, 1f), Shader.TileMode.CLAMP
        )
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        running = true
        if (glowShader == null) buildShaders()
        invalidate()
    }

    override fun onDetachedFromWindow() {
        running = false
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        canvas.drawColor(Color.BLACK)
        if (!animated) return
        val w = width.toFloat()
        val h = height.toFloat()
        val m = min(w, h)
        val t = (System.nanoTime() - t0) / 1e9
        val k = intensity

        for ((i, o) in orbs.withIndex()) {
            val cx = (w * (0.5 + 0.34 * sin(t * o.sx * 2 * PI + o.px))).toFloat()
            val cy = (h * (0.5 + 0.30 * cos(t * o.sy * 2 * PI + o.py))).toFloat()
            val r = (m * (o.size + 0.08 * sin(t * 0.25 + o.px))).toFloat()
            orbPaint.shader = shaders[i]
            orbPaint.alpha = (255 * k).toInt()
            canvas.save()
            canvas.translate(cx, cy)
            canvas.scale(r, r)
            canvas.drawCircle(0f, 0f, 1f, orbPaint)
            canvas.restore()
        }

        // cerchio che respira (5 s dentro, 5 s fuori)
        val breath = (0.5 - 0.5 * cos(2 * PI * t / 10.0)).toFloat()
        val cx = w / 2f
        val cy = h / 2f
        val rr = m * (0.36f + 0.05f * breath)
        glowPaint.shader = glowShader
        glowPaint.alpha = (255 * k * (0.35f + 0.65f * breath)).toInt()
        canvas.save()
        canvas.translate(cx, cy)
        canvas.scale(rr * 1.25f, rr * 1.25f)
        canvas.drawCircle(0f, 0f, 1f, glowPaint)
        canvas.restore()
        ringPaint.strokeWidth = Ui.dp(context, 1).toFloat().coerceAtLeast(1.5f)
        ringPaint.color = Color.WHITE
        ringPaint.alpha = (70 * k * (0.5f + 0.5f * breath)).toInt()
        canvas.drawCircle(cx, cy, rr, ringPaint)
        ringPaint.alpha = (35 * k * (0.5f + 0.5f * breath)).toInt()
        canvas.drawCircle(cx, cy, rr * 1.13f, ringPaint)

        // stelle
        val d = resources.displayMetrics.density
        for (i in starX.indices) {
            val tw = 0.5 + 0.5 * sin(t * starF[i] + starP[i])
            starPaint.alpha = (255 * 0.55 * k * (0.2 + 0.8 * tw)).toInt()
            canvas.drawCircle(starX[i] * w, starY[i] * h, starR[i] * d, starPaint)
        }

        if (running) postInvalidateDelayed(45)
    }
}
