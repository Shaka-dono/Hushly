package com.hushly.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.IBinder
import android.os.PowerManager
import android.support.v4.media.MediaMetadataCompat
import android.support.v4.media.session.MediaSessionCompat
import android.support.v4.media.session.PlaybackStateCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.media.app.NotificationCompat.MediaStyle

class PlayerService : Service() {

    companion object {
        const val ACTION_PLAY = "com.hushly.app.PLAY"
        const val ACTION_STOP = "com.hushly.app.STOP"
        const val CHANNEL = "playback"
        const val NOTIF_ID = 11

        fun play(c: Context) {
            ContextCompat.startForegroundService(
                c, Intent(c, PlayerService::class.java).setAction(ACTION_PLAY)
            )
        }

        fun stop(c: Context) {
            Player.stop()
        }
    }

    private lateinit var session: MediaSessionCompat
    private var wake: PowerManager.WakeLock? = null
    private var focusReq: AudioFocusRequest? = null
    private var foreground = false

    private val listener: () -> Unit = { onPlayerChanged() }

    private val noisy = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action == AudioManager.ACTION_AUDIO_BECOMING_NOISY) Player.stop()
        }
    }

    override fun onCreate() {
        super.onCreate()
        Player.init(this)
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val ch = NotificationChannel(CHANNEL, getString(R.string.notif_channel), NotificationManager.IMPORTANCE_LOW)
        ch.setShowBadge(false)
        nm.createNotificationChannel(ch)

        session = MediaSessionCompat(this, "Hushly")
        session.setCallback(object : MediaSessionCompat.Callback() {
            override fun onPlay() { if (!Player.isPlaying()) Player.play(this@PlayerService) }
            override fun onPause() { Player.stop() }
            override fun onStop() { Player.stop() }
        })
        session.isActive = true

        ContextCompat.registerReceiver(
            this, noisy, IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
        Player.addListener(listener)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                Player.stop()
                shutdown()
            }
            else -> {
                if (!Player.anyActive()) {
                    Player.applyMix(this, mapOf("rain" to 0.6f))
                }
                enterForeground()
                requestFocus()
                acquireWake()
                Player.play(this)
                Dnd.sync(this)
            }
        }
        return START_NOT_STICKY
    }

    private fun enterForeground() {
        ServiceCompat.startForeground(
            this, NOTIF_ID, buildNotification(),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
        )
        foreground = true
    }

    private fun onPlayerChanged() {
        Dnd.sync(this)
        if (!Player.isPlaying()) {
            shutdown()
        } else if (foreground) {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.notify(NOTIF_ID, buildNotification())
        }
    }

    private fun title(): String {
        val ids = Player.activeIds()
        if (ids.isEmpty()) return getString(R.string.app_name)
        return ids.joinToString(" + ") { getString(Sounds.all[Sounds.indexOf(it)].nameRes) }
    }

    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stopI = PendingIntent.getService(
            this, 1, Intent(this, PlayerService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val t = title()
        session.setMetadata(
            MediaMetadataCompat.Builder()
                .putString(MediaMetadataCompat.METADATA_KEY_TITLE, t)
                .putString(MediaMetadataCompat.METADATA_KEY_ARTIST, getString(R.string.app_name))
                .build()
        )
        session.setPlaybackState(
            PlaybackStateCompat.Builder()
                .setActions(PlaybackStateCompat.ACTION_PLAY or PlaybackStateCompat.ACTION_PAUSE or PlaybackStateCompat.ACTION_STOP)
                .setState(PlaybackStateCompat.STATE_PLAYING, 0, 1f)
                .build()
        )
        val b = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_moon)
            .setContentTitle(t)
            .setContentIntent(open)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setSilent(true)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setCategory(NotificationCompat.CATEGORY_TRANSPORT)
            .addAction(R.drawable.ic_stat_moon, getString(R.string.notif_stop), stopI)
            .setStyle(MediaStyle().setMediaSession(session.sessionToken).setShowActionsInCompactView(0))
        val rem = Player.remainingMs()
        if (rem >= 0) {
            b.setContentText(getString(R.string.notif_text_timer))
            b.setShowWhen(true)
            b.setUsesChronometer(true)
            b.setChronometerCountDown(true)
            b.setWhen(System.currentTimeMillis() + rem)
        }
        return b.build()
    }

    private fun requestFocus() {
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            .setOnAudioFocusChangeListener { change ->
                when (change) {
                    AudioManager.AUDIOFOCUS_LOSS,
                    AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> Player.stop()
                    AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> Player.duck(true)
                    AudioManager.AUDIOFOCUS_GAIN -> Player.duck(false)
                }
            }
            .build()
        focusReq = req
        am.requestAudioFocus(req)
    }

    private fun abandonFocus() {
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        focusReq?.let { am.abandonAudioFocusRequest(it) }
        focusReq = null
        Player.duck(false)
    }

    private fun acquireWake() {
        if (wake?.isHeld == true) return
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "Hushly:play").also {
            it.acquire(14 * 60 * 60 * 1000L)
        }
    }

    private fun shutdown() {
        try { wake?.let { if (it.isHeld) it.release() } } catch (e: Exception) { }
        abandonFocus()
        Dnd.disable(this)
        if (foreground) {
            ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
            foreground = false
        }
        stopSelf()
    }

    override fun onDestroy() {
        Player.removeListener(listener)
        try { unregisterReceiver(noisy) } catch (e: Exception) { }
        session.isActive = false
        session.release()
        try { wake?.let { if (it.isHeld) it.release() } } catch (e: Exception) { }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
