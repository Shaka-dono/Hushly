package com.hushly.app

import android.Manifest
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.materialswitch.MaterialSwitch
import java.util.Locale
import kotlin.concurrent.thread

class SettingsActivity : AppCompatActivity() {

    private lateinit var list: LinearLayout

    private val locPerm =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
            if (ok) {
                Weather.refreshLocation(this)
            } else {
                Toast.makeText(this, R.string.weather_need_loc, Toast.LENGTH_LONG).show()
            }
            Weather.clearCache(this)
            render()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        Appearance.apply(this)
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        val head = LinearLayout(this)
        head.gravity = Gravity.CENTER_VERTICAL
        head.setPadding(dp(16), dp(12), dp(16), dp(4))
        val back = TextView(this)
        back.text = "‹"
        back.textSize = 28f
        back.gravity = Gravity.CENTER
        back.setTextColor(Ui.text(this))
        back.setBackgroundResource(R.drawable.bg_circle_btn)
        back.setOnClickListener { finish() }
        head.addView(back, LinearLayout.LayoutParams(dp(44), dp(44)))
        val t = Ui.label(this, getString(R.string.set_title), 30f, Ui.text(this), true)
        t.setPadding(dp(14), 0, 0, 0)
        head.addView(t)
        root.addView(head)

        val scroll = ScrollView(this)
        list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        list.setPadding(0, 0, 0, dp(32))
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
        render()
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    private fun dp(v: Int) = Ui.dp(this, v)

    private fun newCard(title: String): LinearLayout {
        val t = Ui.label(this, title.uppercase(), 12.5f, Ui.secondary(this), true)
        t.letterSpacing = 0.04f
        t.setPadding(dp(32), dp(24), dp(16), dp(8))
        list.addView(t)
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.setBackgroundResource(R.drawable.bg_card)
        card.clipToOutline = true
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.setMargins(dp(16), 0, dp(16), 0)
        list.addView(card, lp)
        return card
    }

    private fun addRow(
        card: LinearLayout, title: String, summary: String?, trailing: View?, onClick: (() -> Unit)?
    ) {
        if (card.childCount > 0) {
            val div = View(this)
            div.setBackgroundColor(Ui.outline(this))
            val dl = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1)
            dl.marginStart = dp(16)
            card.addView(div, dl)
        }
        val row = LinearLayout(this)
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(16), dp(14), dp(16), dp(14))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.addView(Ui.label(this, title, 17f, Ui.text(this)))
        if (summary != null) {
            val st = Ui.label(this, summary, 13f, Ui.secondary(this))
            st.setPadding(0, dp(2), 0, 0)
            col.addView(st)
        }
        row.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        if (trailing != null) row.addView(trailing)
        if (onClick != null) {
            val tv = TypedValue()
            theme.resolveAttribute(android.R.attr.selectableItemBackground, tv, true)
            row.setBackgroundResource(tv.resourceId)
            row.setOnClickListener { Ui.tap(it); onClick() }
        }
        card.addView(row)
    }

    private fun valueText(s: String) = Ui.label(this, s, 15f, Ui.secondary(this))

    private fun choiceRow(
        card: LinearLayout, title: String, entries: List<String>, values: List<String>,
        current: String, onPick: (String) -> Unit
    ) {
        val idx = values.indexOf(current).coerceAtLeast(0)
        addRow(card, title, null, valueText(entries[idx] + "  ›")) {
            MaterialAlertDialogBuilder(this)
                .setTitle(title)
                .setSingleChoiceItems(entries.toTypedArray(), idx) { d, w ->
                    d.dismiss()
                    onPick(values[w])
                    render()
                }
                .show()
        }
    }

    private fun switchRow(
        card: LinearLayout, title: String, summary: String?, checked: Boolean, onChange: (Boolean) -> Unit
    ) {
        val sw = MaterialSwitch(this)
        sw.isChecked = checked
        sw.setOnClickListener { Ui.tap(it); onChange(sw.isChecked) }
        addRow(card, title, summary, sw, null)
    }

    private fun putBool(key: String, v: Boolean) = Prefs.sp(this).edit().putBoolean(key, v).apply()
    private fun putStr(key: String, v: String) = Prefs.sp(this).edit().putString(key, v).apply()

    private fun render() {
        list.removeAllViews()
        val sp = Prefs.sp(this)

        // ---- aspetto ----
        val look = newCard(getString(R.string.set_sec_look))
        val accentNames = resources.getStringArray(R.array.accent_names).toList()
        choiceRow(look, getString(R.string.set_accent), accentNames, Appearance.accentIds, Prefs.accent(this)) {
            putStr("accent", it)
            recreate()
        }
        val curLang = AppCompatDelegate.getApplicationLocales().let { if (it.isEmpty()) "" else it[0]?.language ?: "" }
        choiceRow(
            look, getString(R.string.set_language),
            listOf(getString(R.string.lang_system), getString(R.string.lang_en), getString(R.string.lang_it)),
            listOf("", "en", "it"), curLang
        ) {
            AppCompatDelegate.setApplicationLocales(
                if (it.isEmpty()) LocaleListCompat.getEmptyLocaleList() else LocaleListCompat.forLanguageTags(it)
            )
        }

        // ---- sonno ----
        val sleep = newCard(getString(R.string.set_sec_sleep))
        val fades = listOf(10, 30, 60, 120, 300)
        choiceRow(
            sleep, getString(R.string.set_fade), fades.map { Ui.fmtSeconds(this, it) },
            fades.map { it.toString() }, Prefs.fadeSec(this).toString()
        ) { sp.edit().putInt("fade_sec", it.toInt()).apply() }

        val access = Dnd.hasAccess(this)
        switchRow(
            sleep, getString(R.string.set_dnd_timer), getString(R.string.main_dnd_sub),
            Prefs.dndOn(this) && access
        ) { on ->
            if (on && !access) {
                putBool("dnd_on", true)
                startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
            } else {
                putBool("dnd_on", on)
            }
            Player.notifyChanged()
            render()
        }
        switchRow(sleep, getString(R.string.set_dnd_calls), null, Prefs.dndCalls(this)) {
            putBool("dnd_calls", it)
            Player.notifyChanged()
        }
        addRow(
            sleep, getString(R.string.set_dnd_access),
            getString(if (access) R.string.granted else R.string.not_granted), null
        ) { startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)) }

        // ---- schermata notte ----
        val night = newCard(getString(R.string.set_sec_night))
        switchRow(night, getString(R.string.set_night_auto), null, Prefs.nightAuto(this)) { putBool("night_auto", it) }
        switchRow(night, getString(R.string.set_night_anim), null, Prefs.nightAnim(this)) { putBool("night_anim", it) }
        choiceRow(
            night, getString(R.string.set_night_bright),
            listOf(getString(R.string.bright_low), getString(R.string.bright_mid), getString(R.string.bright_high)),
            listOf("low", "mid", "high"), Prefs.nightBright(this)
        ) { putStr("night_bright", it) }

        // ---- meteo e orologio ----
        val wx = newCard(getString(R.string.set_sec_weather))
        val mode = Prefs.weatherMode(this)
        choiceRow(
            wx, getString(R.string.set_weather_mode),
            listOf(getString(R.string.weather_off), getString(R.string.weather_loc), getString(R.string.weather_city)),
            listOf("off", "loc", "city"), mode
        ) {
            putStr("weather_mode", it)
            Weather.clearCache(this)
            if (it == "loc" && !Weather.hasLocationPermission(this)) {
                locPerm.launch(Manifest.permission.ACCESS_COARSE_LOCATION)
            }
        }
        if (mode == "city") {
            addRow(
                wx, getString(R.string.set_city), sp.getString("city_name", "—"),
                valueText("›")
            ) { cityDialog() }
        }
        choiceRow(
            wx, getString(R.string.set_units),
            listOf(getString(R.string.units_auto), "°C", "°F"), listOf("auto", "c", "f"), Prefs.units(this)
        ) { putStr("units", it) }
        choiceRow(
            wx, getString(R.string.set_clock),
            listOf(getString(R.string.clock_auto), getString(R.string.clock_24), getString(R.string.clock_12)),
            listOf("auto", "24", "12"), Prefs.clock(this)
        ) { putStr("clock", it) }

        // ---- info ----
        val about = newCard(getString(R.string.set_sec_about))
        val ver = try { packageManager.getPackageInfo(packageName, 0).versionName ?: "" } catch (e: Exception) { "" }
        addRow(about, getString(R.string.set_version), null, valueText(ver), null)
        addRow(about, getString(R.string.set_weather_credit), null, null, null)
    }

    private fun cityDialog() {
        val et = EditText(this)
        et.inputType = InputType.TYPE_CLASS_TEXT
        et.setSingleLine()
        et.setText(Prefs.sp(this).getString("city_name", ""))
        val wrap = LinearLayout(this)
        wrap.setPadding(dp(24), dp(8), dp(24), 0)
        wrap.addView(et, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.set_city)
            .setView(wrap)
            .setPositiveButton(R.string.btn_ok) { _, _ ->
                val q = et.text.toString().trim()
                if (q.isNotEmpty()) {
                    val lang = Locale.getDefault().language
                    thread {
                        val r = Weather.geocode(q, lang)
                        runOnUiThread {
                            if (r == null) {
                                Toast.makeText(this, R.string.city_not_found, Toast.LENGTH_LONG).show()
                            } else {
                                Prefs.sp(this).edit()
                                    .putString("city_name", r.first)
                                    .putFloat("city_lat", r.second.toFloat())
                                    .putFloat("city_lon", r.third.toFloat())
                                    .apply()
                                Weather.clearCache(this)
                                render()
                            }
                        }
                    }
                }
            }
            .setNegativeButton(R.string.btn_cancel, null)
            .show()
    }
}
