package com.hushly.app

import android.graphics.Color
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

const val FS = 44100.0
private const val TWO_PI = 2.0 * PI

/** Tutti i suoni sono generati matematicamente: nessun file audio, niente internet. */
abstract class Gen {
    abstract fun next(): Double
}

class Rng(seed: Int) {
    private var x: Int = (seed * 1664525 + 1013904223).let { if (it == 0) 88172645 else it }
    fun w(): Double {
        x = x xor (x shl 13)
        x = x xor (x ushr 17)
        x = x xor (x shl 5)
        return x / 2147483648.0
    }
    fun u(): Double = (w() + 1.0) * 0.5
}

class PinkF {
    private var b0 = 0.0
    private var b1 = 0.0
    private var b2 = 0.0
    fun p(w: Double): Double {
        b0 = 0.99765 * b0 + w * 0.0990460
        b1 = 0.96300 * b1 + w * 0.2965164
        b2 = 0.57000 * b2 + w * 1.0526913
        return b0 + b1 + b2 + w * 0.1848
    }
}

class LpF(fc: Double) {
    private val a = 1.0 - exp(-TWO_PI * fc / FS)
    private var y = 0.0
    fun p(x: Double): Double {
        y += a * (x - y)
        return y
    }
}

class HpF(fc: Double) {
    private val l = LpF(fc)
    fun p(x: Double): Double = x - l.p(x)
}

class SvfBand {
    private var low = 0.0
    private var band = 0.0
    fun p(x: Double, fc: Double, q: Double): Double {
        val f = 2.0 * sin(PI * fc / FS)
        low += f * band
        val high = x - low - q * band
        band += f * high
        return band
    }
}

class WhiteGen(seed: Int) : Gen() {
    private val r = Rng(seed)
    override fun next() = r.w() * 0.5
}

class PinkGen(seed: Int) : Gen() {
    private val r = Rng(seed)
    private val p = PinkF()
    override fun next() = p.p(r.w()) * 0.25
}

class BrownGen(seed: Int) : Gen() {
    private val r = Rng(seed)
    private var b = 0.0
    override fun next(): Double {
        b = (b + 0.02 * r.w()) / 1.02
        return b * 3.0
    }
}

class RainGen(seed: Int, private val heavy: Double = 1.0) : Gen() {
    private val r = Rng(seed)
    private val pk = PinkF()
    private val hp = HpF(400.0)
    private val lp = LpF(6500.0)
    private val n = 24
    private val f = DoubleArray(n)
    private val a = DoubleArray(n)
    private val d = DoubleArray(n)
    private val ph = DoubleArray(n)
    private var k = 0
    private val rate = 110.0 * heavy / FS

    override fun next(): Double {
        val w = r.w()
        val bed = lp.p(hp.p(pk.p(w))) * 0.55 * (0.6 + 0.4 * heavy)
        if (r.u() < rate) {
            val i = k
            k = (k + 1) % n
            f[i] = 1800.0 + r.u() * 3200.0
            val u = r.u()
            a[i] = (0.15 + 0.85 * u * u) * 0.5
            d[i] = exp(-1.0 / (FS * (0.004 + 0.012 * r.u())))
            ph[i] = 0.0
        }
        var o = 0.0
        for (i in 0 until n) {
            if (a[i] > 0.0005) {
                o += sin(ph[i]) * a[i]
                ph[i] += TWO_PI * f[i] / FS
                a[i] *= d[i]
            }
        }
        return bed + o * 0.6
    }
}

class ThunderGen(seed: Int) : Gen() {
    private val r = Rng(seed)
    private var b = 0.0
    private val lp = LpF(110.0)
    private val lp2 = LpF(70.0)
    private var t = (FS * (4.0 + r.u() * 8.0)).toInt()
    private var env = 0.0
    private var att = 0.0
    private var on = false
    private var amp = 0.0
    private var decay = 0.9999

    override fun next(): Double {
        t--
        if (t <= 0) {
            t = (FS * (9.0 + r.u() * 18.0)).toInt()
            on = true
            att = 0.0
            amp = 0.5 + 0.5 * r.u()
            decay = exp(-1.0 / (FS * (1.5 + 2.5 * r.u())))
            env = 0.0
        }
        val w = r.w()
        b = (b + 0.02 * w) / 1.02
        val x = lp2.p(lp.p(b * 3.0 + w * 0.3))
        if (on) {
            if (att < 1.0) {
                att = min(1.0, att + 1.0 / (FS * 0.6))
                env = att * amp
            } else {
                env *= decay
            }
            if (env < 0.001 && att >= 1.0) {
                on = false
                env = 0.0
            }
        }
        return x * env * 3.5
    }
}

class StormGen(seed: Int) : Gen() {
    private val rain = RainGen(seed, 1.8)
    private val th = ThunderGen(seed + 77)
    override fun next() = rain.next() + th.next()
}

class WindGen(seed: Int) : Gen() {
    private val r = Rng(seed)
    private val pk = PinkF()
    private val s = SvfBand()
    private var p1 = r.u() * TWO_PI
    private var p2 = r.u() * TWO_PI
    private var p3 = r.u() * TWO_PI
    override fun next(): Double {
        p1 += TWO_PI * 0.063 / FS; if (p1 > TWO_PI) p1 -= TWO_PI
        p2 += TWO_PI * 0.11 / FS; if (p2 > TWO_PI) p2 -= TWO_PI
        p3 += TWO_PI * 0.047 / FS; if (p3 > TWO_PI) p3 -= TWO_PI
        val fc = 520.0 + 260.0 * sin(p1) + 140.0 * sin(p2)
        val amp = 0.65 + 0.35 * sin(p3)
        return s.p(pk.p(r.w()), fc, 0.55) * amp * 0.9
    }
}

class OceanGen(seed: Int) : Gen() {
    private val r = Rng(seed)
    private var b = 0.0
    private val lp = LpF(900.0)
    private val hp = HpF(2500.0)
    private val pk = PinkF()
    private var ph = r.u() * TWO_PI
    private var per = 8.0 + r.u() * 3.0
    override fun next(): Double {
        ph += TWO_PI / (per * FS)
        if (ph > TWO_PI) {
            ph -= TWO_PI
            per = 7.0 + r.u() * 5.0
        }
        val sw = 0.5 + 0.5 * sin(ph - 1.5)
        val e = sw * sw
        val w = r.w()
        b = (b + 0.02 * w) / 1.02
        val body = lp.p(pk.p(w)) * (0.25 + 0.9 * e) * 2.0
        val foam = hp.p(w) * max(0.0, e - 0.5) * 0.8
        return body + foam + b * 0.5
    }
}

class FanGen(seed: Int) : Gen() {
    private val r = Rng(seed)
    private val lp = LpF(1400.0)
    private val lp2 = LpF(5000.0)
    private val pk = PinkF()
    private var ph = 0.0
    private var ph2 = 0.0
    override fun next(): Double {
        ph += TWO_PI * 31.0 / FS; if (ph > TWO_PI) ph -= TWO_PI
        ph2 += TWO_PI * 118.0 / FS; if (ph2 > TWO_PI) ph2 -= TWO_PI
        val w = r.w()
        val x = lp.p(pk.p(w)) * 1.6
        return x * (1.0 + 0.06 * sin(ph)) + sin(ph2) * 0.035 + lp2.p(w) * 0.08
    }
}

class StreamGen(seed: Int) : Gen() {
    private val r = Rng(seed)
    private val pk = PinkF()
    private val s = SvfBand()
    private val hp = HpF(300.0)
    private var ph = 0.0
    private var ph2 = 0.0
    private val n = 14
    private val f = DoubleArray(n)
    private val a = DoubleArray(n)
    private val pv = DoubleArray(n)
    private val up = DoubleArray(n)
    private val d = DoubleArray(n)
    private var k = 0
    private val rate = 26.0 / FS

    override fun next(): Double {
        ph += TWO_PI * 0.4 / FS; if (ph > TWO_PI) ph -= TWO_PI
        ph2 += TWO_PI * 3.1 / FS; if (ph2 > TWO_PI) ph2 -= TWO_PI
        val w = r.w()
        val fc = 1900.0 + 500.0 * sin(ph) + 250.0 * sin(ph2)
        val bed = s.p(w, fc, 0.9) * 0.55 + hp.p(pk.p(w)) * 0.25
        if (r.u() < rate) {
            val i = k
            k = (k + 1) % n
            f[i] = 450.0 + r.u() * 900.0
            a[i] = 0.12 + 0.25 * r.u()
            up[i] = 1.0 + (0.00012 + 0.0003 * r.u())
            d[i] = exp(-1.0 / (FS * (0.015 + 0.03 * r.u())))
            pv[i] = 0.0
        }
        var o = 0.0
        for (i in 0 until n) {
            if (a[i] > 0.001) {
                o += sin(pv[i]) * a[i]
                pv[i] += TWO_PI * f[i] / FS
                f[i] *= up[i]
                a[i] *= d[i]
            }
        }
        return bed + o * 0.7
    }
}

class FireGen(seed: Int) : Gen() {
    private val r = Rng(seed)
    private var b = 0.0
    private val lp = LpF(260.0)
    private val hp = HpF(1500.0)
    private val pk = PinkF()
    private val lp2 = LpF(7000.0)
    private var ph = r.u() * TWO_PI
    private val n = 8
    private val a = DoubleArray(n)
    private val d = DoubleArray(n)
    private var k = 0
    private val rate = 14.0 / FS

    override fun next(): Double {
        ph += TWO_PI * 0.9 / FS; if (ph > TWO_PI) ph -= TWO_PI
        val w = r.w()
        b = (b + 0.02 * w) / 1.02
        val rumble = lp.p(b * 3.0 + w * 0.2) * (0.8 + 0.3 * sin(ph)) * 1.5
        val hiss = hp.p(pk.p(w)) * 0.07
        if (r.u() < rate) {
            val i = k
            k = (k + 1) % n
            val u = r.u()
            a[i] = (0.2 + 0.8 * u * u * u) * 0.9
            d[i] = exp(-1.0 / (FS * (0.0015 + 0.006 * r.u())))
        }
        var o = 0.0
        for (i in 0 until n) {
            if (a[i] > 0.002) {
                o += r.w() * a[i]
                a[i] *= d[i]
            }
        }
        return rumble + hiss + lp2.p(o) * 0.9
    }
}

class SoundDef(
    val id: String,
    val nameRes: Int,
    val emoji: String,
    val color: Int,
    /** guadagno di normalizzazione: porta tutti i suoni circa allo stesso volume percepito */
    val norm: Double,
    val make: (Int) -> Gen
)

object Sounds {
    val all: List<SoundDef> = listOf(
        SoundDef("white", R.string.s_white, "📻", Color.parseColor("#C7CBD9"), 0.485) { WhiteGen(it) },
        SoundDef("pink", R.string.s_pink, "🌸", Color.parseColor("#FF9CC7"), 0.327) { PinkGen(it) },
        SoundDef("brown", R.string.s_brown, "🟤", Color.parseColor("#C9A27A"), 0.814) { BrownGen(it) },
        SoundDef("rain", R.string.s_rain, "🌧️", Color.parseColor("#7CB4FF"), 0.265) { RainGen(it) },
        SoundDef("storm", R.string.s_storm, "⛈️", Color.parseColor("#A99BFF"), 0.199) { StormGen(it) },
        SoundDef("wind", R.string.s_wind, "💨", Color.parseColor("#8FE3D0"), 0.240) { WindGen(it) },
        SoundDef("ocean", R.string.s_ocean, "🌊", Color.parseColor("#4FC3F7"), 0.074) { OceanGen(it) },
        SoundDef("fan", R.string.s_fan, "🌀", Color.parseColor("#B0BEC5"), 0.061) { FanGen(it) },
        SoundDef("stream", R.string.s_stream, "💧", Color.parseColor("#6EE7B7"), 0.348) { StreamGen(it) },
        SoundDef("fire", R.string.s_fire, "🔥", Color.parseColor("#FFA24D"), 0.722) { FireGen(it) }
    )

    fun indexOf(id: String): Int = all.indexOfFirst { it.id == id }
}
