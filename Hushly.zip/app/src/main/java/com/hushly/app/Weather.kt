package com.hushly.app

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.os.Handler
import android.os.Looper
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale
import kotlin.concurrent.thread

class WeatherInfo(val tempC: Double, val code: Int, val isDay: Boolean) {
    fun emoji(): String = when (code) {
        0 -> if (isDay) "☀️" else "🌙"
        1, 2 -> if (isDay) "⛅" else "☁️"
        3 -> "☁️"
        45, 48 -> "🌫️"
        in 51..57 -> "🌦️"
        in 61..67 -> "🌧️"
        in 71..77, 85, 86 -> "❄️"
        in 80..82 -> "🌧️"
        in 95..99 -> "⛈️"
        else -> "🌡️"
    }

    fun labelRes(): Int = when (code) {
        0 -> R.string.w_clear
        1, 2 -> R.string.w_partly
        3 -> R.string.w_cloudy
        45, 48 -> R.string.w_fog
        in 51..57 -> R.string.w_drizzle
        in 61..67 -> R.string.w_rain
        in 71..77, 85, 86 -> R.string.w_snow
        in 80..82 -> R.string.w_showers
        in 95..99 -> R.string.w_thunder
        else -> R.string.w_clear
    }
}

/**
 * Meteo da Open-Meteo.com (nessuna chiave API). Il piano gratuito è per uso non commerciale:
 * prima di vendere l'app serve il piano commerciale (o un altro provider).
 */
object Weather {
    private val main = Handler(Looper.getMainLooper())

    fun hasLocationPermission(c: Context): Boolean =
        ContextCompat.checkSelfPermission(c, Manifest.permission.ACCESS_COARSE_LOCATION) ==
                PackageManager.PERMISSION_GRANTED

    /** Restituisce il meteo (dalla cache se recente) sul thread principale; null se non disponibile. */
    fun get(c: Context, cb: (WeatherInfo?) -> Unit) {
        val app = c.applicationContext
        val mode = Prefs.weatherMode(app)
        if (mode == "off") { cb(null); return }
        val sp = Prefs.sp(app)
        val ageMs = System.currentTimeMillis() - sp.getLong("w_time", 0L)
        if (ageMs < 25 * 60_000L && sp.contains("w_temp") && sp.getString("w_mode", "") == mode) {
            cb(WeatherInfo(sp.getFloat("w_temp", 0f).toDouble(), sp.getInt("w_code", 0), sp.getBoolean("w_day", true)))
            return
        }
        thread {
            var info: WeatherInfo? = null
            try {
                val pos = position(app, mode)
                if (pos != null) {
                    info = fetch(pos.first, pos.second)
                    if (info != null) {
                        sp.edit()
                            .putLong("w_time", System.currentTimeMillis())
                            .putString("w_mode", mode)
                            .putFloat("w_temp", info.tempC.toFloat())
                            .putInt("w_code", info.code)
                            .putBoolean("w_day", info.isDay)
                            .apply()
                    }
                }
            } catch (e: Exception) {
            }
            main.post { cb(info) }
        }
    }

    private fun position(c: Context, mode: String): Pair<Double, Double>? {
        val sp = Prefs.sp(c)
        if (mode == "city") {
            if (!sp.contains("city_lat")) return null
            return Pair(sp.getFloat("city_lat", 0f).toDouble(), sp.getFloat("city_lon", 0f).toDouble())
        }
        if (!hasLocationPermission(c)) {
            return if (sp.contains("last_lat"))
                Pair(sp.getFloat("last_lat", 0f).toDouble(), sp.getFloat("last_lon", 0f).toDouble()) else null
        }
        val lm = c.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        var best: Location? = null
        try {
            for (p in lm.getProviders(true)) {
                val l = lm.getLastKnownLocation(p) ?: continue
                if (best == null || l.time > best!!.time) best = l
            }
        } catch (e: SecurityException) {
        }
        if (best != null) {
            sp.edit().putFloat("last_lat", best!!.latitude.toFloat()).putFloat("last_lon", best!!.longitude.toFloat()).apply()
            return Pair(best!!.latitude, best!!.longitude)
        }
        return if (sp.contains("last_lat"))
            Pair(sp.getFloat("last_lat", 0f).toDouble(), sp.getFloat("last_lon", 0f).toDouble()) else null
    }

    private fun httpGet(url: String): String {
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.connectTimeout = 8000
        conn.readTimeout = 8000
        try {
            return conn.inputStream.bufferedReader().use { it.readText() }
        } finally {
            conn.disconnect()
        }
    }

    private fun fetch(lat: Double, lon: Double): WeatherInfo? {
        val url = "https://api.open-meteo.com/v1/forecast?latitude=%.4f&longitude=%.4f&current=temperature_2m,weather_code,is_day&timezone=auto"
            .format(Locale.US, lat, lon)
        val cur = JSONObject(httpGet(url)).getJSONObject("current")
        return WeatherInfo(cur.getDouble("temperature_2m"), cur.getInt("weather_code"), cur.getInt("is_day") == 1)
    }

    /** Cerca una città; restituisce (nome, lat, lon) o null. Da chiamare fuori dal thread principale. */
    fun geocode(name: String, lang: String): Triple<String, Double, Double>? {
        return try {
            val url = "https://geocoding-api.open-meteo.com/v1/search?name=" +
                    URLEncoder.encode(name, "UTF-8") + "&count=1&language=" + lang + "&format=json"
            val arr = JSONObject(httpGet(url)).optJSONArray("results") ?: return null
            val o = arr.getJSONObject(0)
            Triple(o.getString("name"), o.getDouble("latitude"), o.getDouble("longitude"))
        } catch (e: Exception) {
            null
        }
    }

    fun clearCache(c: Context) {
        Prefs.sp(c).edit().remove("w_time").remove("w_mode").apply()
    }

    /** Aggiorna la posizione con una richiesta singola (se non c'è una ultima posizione nota). */
    fun refreshLocation(c: Context) {
        if (!hasLocationPermission(c) || android.os.Build.VERSION.SDK_INT < 30) return
        try {
            val lm = c.getSystemService(Context.LOCATION_SERVICE) as LocationManager
            val provider = when {
                lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER) -> LocationManager.NETWORK_PROVIDER
                lm.isProviderEnabled(LocationManager.GPS_PROVIDER) -> LocationManager.GPS_PROVIDER
                else -> return
            }
            lm.getCurrentLocation(provider, null, ContextCompat.getMainExecutor(c)) { loc ->
                if (loc != null) {
                    Prefs.sp(c).edit().putFloat("last_lat", loc.latitude.toFloat())
                        .putFloat("last_lon", loc.longitude.toFloat()).apply()
                    clearCache(c)
                }
            }
        } catch (e: SecurityException) {
        }
    }
}
