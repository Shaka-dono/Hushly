package com.hushly.app

import android.content.Context
import android.content.SharedPreferences
import androidx.preference.PreferenceManager
import org.json.JSONArray
import org.json.JSONObject

class Mix(val name: String, val levels: Map<String, Float>)

object Prefs {
    fun sp(c: Context): SharedPreferences = PreferenceManager.getDefaultSharedPreferences(c)

    fun accent(c: Context): String = sp(c).getString("accent", "indigo") ?: "indigo"

    // livelli dei suoni (0..1)
    fun level(c: Context, id: String): Float = sp(c).getFloat("lvl_$id", 0f)
    fun lastLevel(c: Context, id: String): Float = sp(c).getFloat("last_$id", 0.6f)
    fun saveLevel(c: Context, id: String, v: Float) {
        val e = sp(c).edit().putFloat("lvl_$id", v)
        if (v > 0.02f) e.putFloat("last_$id", v)
        e.apply()
    }

    fun timerMin(c: Context): Int = sp(c).getInt("timer_min", 45)
    fun setTimerMin(c: Context, m: Int) = sp(c).edit().putInt("timer_min", m).apply()
    fun fadeSec(c: Context): Int = sp(c).getInt("fade_sec", 60)

    fun dndOn(c: Context): Boolean = sp(c).getBoolean("dnd_on", false)
    fun dndCalls(c: Context): Boolean = sp(c).getBoolean("dnd_calls", false)

    fun nightAuto(c: Context): Boolean = sp(c).getBoolean("night_auto", true)
    fun nightAnim(c: Context): Boolean = sp(c).getBoolean("night_anim", true)
    fun nightBright(c: Context): String = sp(c).getString("night_bright", "low") ?: "low"

    fun weatherMode(c: Context): String = sp(c).getString("weather_mode", "loc") ?: "loc"
    fun units(c: Context): String = sp(c).getString("units", "auto") ?: "auto"
    fun clock(c: Context): String = sp(c).getString("clock", "auto") ?: "auto"

    // mix salvati dall'utente
    fun mixes(c: Context): MutableList<Mix> {
        val out = mutableListOf<Mix>()
        try {
            val arr = JSONArray(sp(c).getString("mixes", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val lv = o.getJSONObject("levels")
                val m = mutableMapOf<String, Float>()
                for (k in lv.keys()) m[k] = lv.getDouble(k).toFloat()
                out.add(Mix(o.getString("name"), m))
            }
        } catch (e: Exception) {
        }
        return out
    }

    fun saveMixes(c: Context, list: List<Mix>) {
        val arr = JSONArray()
        for (m in list) {
            val o = JSONObject()
            o.put("name", m.name)
            val lv = JSONObject()
            for ((k, v) in m.levels) lv.put(k, v.toDouble())
            o.put("levels", lv)
            arr.put(o)
        }
        sp(c).edit().putString("mixes", arr.toString()).apply()
    }
}
