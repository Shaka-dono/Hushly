package com.hushly.app

import android.app.Activity

object Appearance {
    fun apply(a: Activity) {
        a.setTheme(
            when (Prefs.accent(a)) {
                "teal" -> R.style.Theme_Hushly_Teal
                "purple" -> R.style.Theme_Hushly_Purple
                "pink" -> R.style.Theme_Hushly_Pink
                "orange" -> R.style.Theme_Hushly_Orange
                "green" -> R.style.Theme_Hushly_Green
                "blue" -> R.style.Theme_Hushly_Blue
                else -> R.style.Theme_Hushly_Indigo
            }
        )
    }

    val accentIds = listOf("indigo", "teal", "purple", "pink", "orange", "green", "blue")
}
