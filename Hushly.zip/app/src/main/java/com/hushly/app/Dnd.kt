package com.hushly.app

import android.app.AlarmManager
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * "Non disturbare" per la durata del timer.
 * Usa il filtro PRIORITY che lascia passare solo sveglie e audio multimediale (così Hushly continua
 * a suonare), e (opzionale) le chiamate dai preferiti. Le impostazioni precedenti dell'utente vengono
 * salvate e ripristinate alla fine.
 */
object Dnd {
    private const val ACTION_RESTORE = "com.hushly.app.DND_RESTORE"

    private fun nm(c: Context) = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    fun hasAccess(c: Context): Boolean = nm(c).isNotificationPolicyAccessGranted

    fun isActive(c: Context): Boolean = Prefs.sp(c).getBoolean("dnd_active", false)

    /** Allinea lo stato di Non disturbare a quello della riproduzione. */
    fun sync(c: Context) {
        val should = Player.isPlaying() && Player.hasTimer() && Prefs.dndOn(c) && hasAccess(c)
        if (should) {
            val endWall = System.currentTimeMillis() + Player.remainingMs()
            enable(c, endWall)
        } else {
            disable(c)
        }
    }

    private fun enable(c: Context, endWallMs: Long) {
        val n = nm(c)
        val sp = Prefs.sp(c)
        // già attivo con le stesse impostazioni: non riapplicare (evita lavoro a ogni movimento di slider)
        if (sp.getBoolean("dnd_active", false) &&
            Math.abs(endWallMs - sp.getLong("dnd_end", 0L)) < 5000L &&
            sp.getBoolean("dnd_calls_applied", false) == Prefs.dndCalls(c)
        ) return
        if (!sp.getBoolean("dnd_active", false)) {
            val p = n.notificationPolicy
            sp.edit()
                .putBoolean("dnd_active", true)
                .putInt("dnd_prev_filter", n.currentInterruptionFilter)
                .putInt("dnd_prev_cat", p.priorityCategories)
                .putInt("dnd_prev_calls", p.priorityCallSenders)
                .putInt("dnd_prev_msgs", p.priorityMessageSenders)
                .putInt("dnd_prev_vis", p.suppressedVisualEffects)
                .apply()
        }
        var cats = NotificationManager.Policy.PRIORITY_CATEGORY_ALARMS or
                NotificationManager.Policy.PRIORITY_CATEGORY_MEDIA
        val callSenders = NotificationManager.Policy.PRIORITY_SENDERS_STARRED
        if (Prefs.dndCalls(c)) {
            cats = cats or NotificationManager.Policy.PRIORITY_CATEGORY_CALLS
        }
        try {
            n.notificationPolicy = NotificationManager.Policy(
                cats, callSenders, NotificationManager.Policy.PRIORITY_SENDERS_ANY, 0
            )
            n.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY)
        } catch (e: Exception) {
        }
        sp.edit().putLong("dnd_end", endWallMs).putBoolean("dnd_calls_applied", Prefs.dndCalls(c)).apply()
        scheduleSafety(c, endWallMs + 90_000L)
    }

    fun disable(c: Context) {
        val sp = Prefs.sp(c)
        if (!sp.getBoolean("dnd_active", false)) return
        val n = nm(c)
        try {
            if (n.isNotificationPolicyAccessGranted) {
                val prevFilter = sp.getInt("dnd_prev_filter", NotificationManager.INTERRUPTION_FILTER_ALL)
                n.notificationPolicy = NotificationManager.Policy(
                    sp.getInt("dnd_prev_cat", 0),
                    sp.getInt("dnd_prev_calls", NotificationManager.Policy.PRIORITY_SENDERS_ANY),
                    sp.getInt("dnd_prev_msgs", NotificationManager.Policy.PRIORITY_SENDERS_ANY),
                    sp.getInt("dnd_prev_vis", 0)
                )
                // ripristina il filtro solo se è ancora quello impostato da noi
                if (n.currentInterruptionFilter == NotificationManager.INTERRUPTION_FILTER_PRIORITY) {
                    n.setInterruptionFilter(
                        if (prevFilter == NotificationManager.INTERRUPTION_FILTER_UNKNOWN)
                            NotificationManager.INTERRUPTION_FILTER_ALL else prevFilter
                    )
                }
            }
        } catch (e: Exception) {
        }
        sp.edit().putBoolean("dnd_active", false).apply()
        cancelSafety(c)
    }

    private fun safetyIntent(c: Context): PendingIntent {
        val i = Intent(c, DndRestoreReceiver::class.java).setAction(ACTION_RESTORE)
        return PendingIntent.getBroadcast(c, 77, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    private fun scheduleSafety(c: Context, atWallMs: Long) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, atWallMs, safetyIntent(c))
    }

    private fun cancelSafety(c: Context) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(safetyIntent(c))
    }
}

/** Rete di sicurezza: se il servizio viene ucciso o il telefono si riavvia, Non disturbare torna com'era. */
class DndRestoreReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (!Player.isPlaying()) Dnd.disable(context)
    }
}
