package com.hushly.app

import android.app.Application
import androidx.appcompat.app.AppCompatDelegate

class HushlyApp : Application() {
    override fun onCreate() {
        super.onCreate()
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
        // Se l'app è stata chiusa di colpo mentre "Non disturbare" era attivo, lo ripristina.
        if (!Player.isPlaying()) Dnd.disable(this)
    }
}
