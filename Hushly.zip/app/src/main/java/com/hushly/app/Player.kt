package com.hushly.app

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Handler
import android.os.Looper
import android.os.Process
import android.os.SystemClock
import java.util.concurrent.CopyOnWriteArrayList
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.tanh

/**
 * Motore di Hushly: genera l'audio in tempo reale (nessun file) e lo manda a un AudioTrack.
 * Vive nel processo dell'app; il servizio in primo piano lo tiene in vita a schermo spento.
 */
object Player {
    private const val CHUNK = 2048
    private const val OUT_GAIN = 1.4

    private val main = Handler(Looper.getMainLooper())
    private val listeners = CopyOnWriteArrayList<() -> Unit>()
    private val lock = Object()
    private var started = false
    private var thread: Thread? = null

    val count = Sounds.all.size
    val levels = FloatArray(count)
    @Volatile private var wantPlay = false
    @Volatile private var ducked = false
    @Volatile private var timerEnd = 0L      // SystemClock.elapsedRealtime, 0 = nessun timer
    @Volatile private var fadeMs = 60000L

    fun init(c: Context) {
        if (started) return
        started = true
        for (i in 0 until count) levels[i] = Prefs.level(c, Sounds.all[i].id)
    }

    fun addListener(l: () -> Unit) { listeners.add(l) }
    fun removeListener(l: () -> Unit) { listeners.remove(l) }
    fun notifyChanged() {
        main.post { for (l in listeners) l() }
    }

    fun isPlaying(): Boolean = wantPlay
    fun hasTimer(): Boolean = timerEnd != 0L

    /** ms rimanenti, -1 se non c'è un timer */
    fun remainingMs(): Long =
        if (timerEnd == 0L) -1L else max(0L, timerEnd - SystemClock.elapsedRealtime())

    fun anyActive(): Boolean = levels.any { it > 0.02f }

    fun activeIds(): List<String> =
        Sounds.all.filterIndexed { i, _ -> levels[i] > 0.02f }.map { it.id }

    fun setLevel(c: Context, idx: Int, v: Float) {
        levels[idx] = v
        Prefs.saveLevel(c, Sounds.all[idx].id, v)
        notifyChanged()
    }

    fun applyMix(c: Context, mix: Map<String, Float>) {
        for (i in 0 until count) {
            val v = mix[Sounds.all[i].id] ?: 0f
            levels[i] = v
            Prefs.saveLevel(c, Sounds.all[i].id, v)
        }
        notifyChanged()
    }

    fun play(c: Context) {
        val minutes = Prefs.timerMin(c)
        fadeMs = Prefs.fadeSec(c) * 1000L
        timerEnd = if (minutes > 0) SystemClock.elapsedRealtime() + minutes * 60_000L else 0L
        wantPlay = true
        ensureThread()
        synchronized(lock) { lock.notifyAll() }
        notifyChanged()
    }

    fun stop() {
        wantPlay = false
        timerEnd = 0L
        notifyChanged()
    }

    fun setTimer(c: Context, minutes: Int) {
        Prefs.setTimerMin(c, minutes)
        if (wantPlay) {
            fadeMs = Prefs.fadeSec(c) * 1000L
            timerEnd = if (minutes > 0) SystemClock.elapsedRealtime() + minutes * 60_000L else 0L
        }
        notifyChanged()
    }

    fun duck(on: Boolean) { ducked = on }

    private fun ensureThread() {
        if (thread?.isAlive == true) return
        val t = Thread({ audioLoop() }, "hushly-audio")
        t.isDaemon = true
        thread = t
        t.start()
    }

    private fun softClip(x: Double): Double {
        val a = abs(x)
        if (a <= 0.7) return x
        val y = 0.7 + 0.3 * tanh((a - 0.7) / 0.3)
        return if (x < 0) -y else y
    }

    private fun audioLoop() {
        Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO)
        val n = count
        val gens = Array(n) { arrayOfNulls<Gen>(2) }
        val cur = DoubleArray(n)
        val mixL = DoubleArray(CHUNK)
        val mixR = DoubleArray(CHUNK)
        val pcm = ShortArray(CHUNK * 2)
        var master = 0.0
        var dcLx = 0.0
        var dcLy = 0.0
        var dcRx = 0.0
        var dcRy = 0.0

        while (true) {
            synchronized(lock) {
                while (!wantPlay) {
                    try {
                        lock.wait()
                    } catch (e: InterruptedException) {
                        return
                    }
                }
            }
            val bytes = CHUNK * 4 * 4
            val track = try {
                AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setSampleRate(44100)
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                            .build()
                    )
                    .setBufferSizeInBytes(
                        max(
                            bytes,
                            AudioTrack.getMinBufferSize(
                                44100, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_16BIT
                            )
                        )
                    )
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .setPerformanceMode(AudioTrack.PERFORMANCE_MODE_POWER_SAVING)
                    .build()
            } catch (e: Exception) {
                wantPlay = false
                notifyChanged()
                continue
            }
            track.play()
            master = 0.0

            while (true) {
                // ---- timer e dissolvenza finale ----
                var fade = 1.0
                if (wantPlay && timerEnd != 0L) {
                    val rem = timerEnd - SystemClock.elapsedRealtime()
                    if (rem <= 0) {
                        wantPlay = false
                        timerEnd = 0L
                        notifyChanged()
                        fade = 0.0
                    } else if (rem < fadeMs) {
                        val x = rem.toDouble() / fadeMs.toDouble()
                        fade = x * x * (3.0 - 2.0 * x)
                    }
                }
                val target = if (wantPlay) fade * (if (ducked) 0.35 else 1.0) else 0.0
                val up = CHUNK / (FS * 1.5)
                val down = CHUNK / (FS * (if (wantPlay) 0.5 else 0.8))
                val newMaster = if (target > master) min(target, master + up) else max(target, master - down)
                if (!wantPlay && newMaster <= 0.0005 && master <= 0.0005) break

                // ---- mixaggio dei suoni attivi ----
                java.util.Arrays.fill(mixL, 0.0)
                java.util.Arrays.fill(mixR, 0.0)
                for (i in 0 until n) {
                    val lv = levels[i].toDouble()
                    val tg = if (lv > 0.01) Sounds.all[i].norm * lv.pow(1.5) else 0.0
                    var g0 = cur[i]
                    if (tg == 0.0 && g0 < 0.0005) {
                        cur[i] = 0.0
                        continue
                    }
                    var g1 = g0 + (tg - g0) * 0.35
                    if (abs(tg - g1) < 0.0003) g1 = tg
                    cur[i] = g1
                    if (gens[i][0] == null) {
                        gens[i][0] = Sounds.all[i].make(1000 + i * 31)
                        gens[i][1] = Sounds.all[i].make(5000 + i * 57)
                    }
                    val gl = gens[i][0]!!
                    val gr = gens[i][1]!!
                    val step = (g1 - g0) / CHUNK
                    for (j in 0 until CHUNK) {
                        g0 += step
                        mixL[j] += gl.next() * g0
                        mixR[j] += gr.next() * g0
                    }
                }

                // ---- master, filtro DC, limitatore, conversione a PCM16 ----
                val mStep = (newMaster - master) / CHUNK
                var m = master
                for (j in 0 until CHUNK) {
                    m += mStep
                    val xl = mixL[j] * m * OUT_GAIN
                    val xr = mixR[j] * m * OUT_GAIN
                    dcLy = xl - dcLx + 0.995 * dcLy
                    dcLx = xl
                    dcRy = xr - dcRx + 0.995 * dcRy
                    dcRx = xr
                    pcm[2 * j] = (softClip(dcLy) * 32000.0).toInt().toShort()
                    pcm[2 * j + 1] = (softClip(dcRy) * 32000.0).toInt().toShort()
                }
                master = newMaster
                val w = track.write(pcm, 0, pcm.size)
                if (w < 0) break
            }
            try {
                track.stop()
            } catch (e: Exception) {
            }
            track.release()
        }
    }
}
