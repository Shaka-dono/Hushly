package com.hushly.app

import android.Manifest
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.format.DateFormat
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

/**
 * Schermata notte: nero OLED, luminosità minima, sopra la schermata di blocco, schermo tenuto acceso
 * finché la riproduzione è attiva. Mostra ora, data, meteo, suoni e conto alla rovescia del timer
 * immersi in un'animazione lenta. Tocca per i comandi.
 */
class SleepActivity : AppCompatActivity() {

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var calm: CalmView
    private lateinit var content: LinearLayout
    private lateinit var tvTime: TextView
    private lateinit var tvDate: TextView
    private lateinit var tvWeather: TextView
    private lateinit var tvSound: TextView
    private lateinit var tvTimer: TextView
    private lateinit var controls: LinearLayout
    private lateinit var hint: TextView
    private lateinit var btnPlay: TextView
    private var wasPlaying = false
    private var weather: WeatherInfo? = null

    private val listener: () -> Unit = { onPlayerChanged() }

    private val tick = object : Runnable {
        override fun run() {
            updateClock()
            updateTimer()
            handler.postDelayed(this, 1000)
        }
    }

    private val drift = object : Runnable {
        override fun run() {
            val d = Ui.dp(this@SleepActivity, 16)
            val rnd = java.util.Random()
            content.animate().translationX((rnd.nextInt(2 * d) - d).toFloat())
                .translationY((rnd.nextInt(2 * d) - d).toFloat()).setDuration(4000).start()
            handler.postDelayed(this, 60_000)
        }
    }

    private val weatherReload = object : Runnable {
        override fun run() {
            loadWeather()
            handler.postDelayed(this, 30 * 60_000L)
        }
    }

    private val hideControls = Runnable {
        controls.animate().alpha(0f).setDuration(400).withEndAction { controls.visibility = View.INVISIBLE }.start()
    }

    private val hideHint = Runnable { hint.animate().alpha(0f).setDuration(1500).start() }

    private val locPerm =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
            if (ok) Weather.refreshLocation(this)
            Weather.clearCache(this)
            loadWeather()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        Appearance.apply(this)
        super.onCreate(savedInstanceState)
        Player.init(this)

        setShowWhenLocked(true)
        window.setBackgroundDrawable(ColorDrawable(Color.BLACK))
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val lp = window.attributes
        lp.screenBrightness = when (Prefs.nightBright(this)) {
            "high" -> 0.20f
            "mid" -> 0.06f
            else -> 0.01f
        }
        lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        window.attributes = lp
        WindowCompat.setDecorFitsSystemWindows(window, false)
        val ctl = WindowInsetsControllerCompat(window, window.decorView)
        ctl.hide(WindowInsetsCompat.Type.systemBars())
        ctl.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE

        buildUi()
        wasPlaying = Player.isPlaying()
        calm.animated = Prefs.nightAnim(this)

        if (Prefs.weatherMode(this) == "loc" && !Weather.hasLocationPermission(this) &&
            !Prefs.sp(this).getBoolean("loc_asked", false)
        ) {
            Prefs.sp(this).edit().putBoolean("loc_asked", true).apply()
            locPerm.launch(Manifest.permission.ACCESS_COARSE_LOCATION)
        }
    }

    override fun onResume() {
        super.onResume()
        Player.addListener(listener)
        onPlayerChanged()
        updateClock()
        updateTimer()
        handler.post(tick)
        handler.postDelayed(drift, 60_000)
        handler.post(weatherReload)
        handler.postDelayed(hideHint, 7000)
        if (Weather.hasLocationPermission(this) && Prefs.weatherMode(this) == "loc") Weather.refreshLocation(this)
    }

    override fun onPause() {
        super.onPause()
        Player.removeListener(listener)
        handler.removeCallbacksAndMessages(null)
    }

    // ------------------------------------------------------------------ UI

    private fun dp(v: Int) = Ui.dp(this, v)

    private fun whiteText(s: String, sp: Float, alpha: Float, bold: Boolean = false): TextView {
        val t = Ui.label(this, s, sp, Color.WHITE, bold)
        t.alpha = alpha
        t.gravity = Gravity.CENTER
        return t
    }

    private fun pill(text: String, onClick: () -> Unit): TextView {
        val b = Ui.label(this, text, 16f, Color.WHITE, true)
        b.gravity = Gravity.CENTER
        b.setPadding(dp(26), dp(14), dp(26), dp(14))
        b.background = Ui.roundBg(this, Color.argb(60, 255, 255, 255), 30)
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.marginStart = dp(8)
        lp.marginEnd = dp(8)
        b.layoutParams = lp
        b.setOnClickListener { Ui.tap(it); onClick() }
        return b
    }

    private fun buildUi() {
        val root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)
        calm = CalmView(this)
        root.addView(calm, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        content.gravity = Gravity.CENTER_HORIZONTAL
        tvDate = whiteText("", 17f, 0.62f)
        tvTime = whiteText("", 88f, 0.9f)
        tvTime.typeface = Typeface.create("sans-serif-thin", Typeface.NORMAL)
        tvTime.includeFontPadding = false
        tvWeather = whiteText("", 17f, 0.62f)
        tvSound = whiteText("", 18f, 0.8f)
        tvSound.setPadding(dp(32), dp(54), dp(32), 0)
        tvTimer = whiteText("", 40f, 0.9f)
        tvTimer.typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
        tvTimer.setPadding(0, dp(6), 0, 0)
        content.addView(tvDate)
        content.addView(tvTime)
        content.addView(tvWeather)
        content.addView(tvSound)
        content.addView(tvTimer)
        val clp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        clp.gravity = Gravity.CENTER
        root.addView(content, clp)

        hint = whiteText(getString(R.string.night_tap), 13f, 0.35f)
        val hlp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        hlp.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
        hlp.bottomMargin = dp(36)
        root.addView(hint, hlp)

        controls = LinearLayout(this)
        controls.gravity = Gravity.CENTER
        controls.visibility = View.INVISIBLE
        controls.addView(pill(getString(R.string.night_close)) { finish() })
        btnPlay = pill("") {
            if (Player.isPlaying()) PlayerService.stop(this) else PlayerService.play(this)
        }
        controls.addView(btnPlay)
        val ctlp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        ctlp.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
        ctlp.bottomMargin = dp(70)
        root.addView(controls, ctlp)

        root.setOnClickListener {
            handler.removeCallbacks(hideControls)
            controls.animate().cancel()
            controls.alpha = 1f
            controls.visibility = View.VISIBLE
            handler.postDelayed(hideControls, 5000)
        }
        setContentView(root)
    }

    // ------------------------------------------------------------------ aggiornamenti

    private fun onPlayerChanged() {
        val playing = Player.isPlaying()
        if (playing) {
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        } else if (wasPlaying) {
            // riproduzione finita (timer o stop): lascia che lo schermo si spenga da solo
            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            handler.postDelayed({ if (!Player.isPlaying()) finish() }, 3000)
        }
        wasPlaying = playing
        btnPlay.text = getString(if (playing) R.string.night_stop else R.string.notif_play)

        val ids = Player.activeIds()
        tvSound.text = if (ids.isEmpty()) getString(R.string.night_no_sound)
        else ids.joinToString("  +  ") {
            val s = Sounds.all[Sounds.indexOf(it)]
            s.emoji + " " + getString(s.nameRes)
        }
        calm.setPalette(ids.take(3).map { Sounds.all[Sounds.indexOf(it)].color })
        updateTimer()
    }

    private fun is24h(): Boolean = when (Prefs.clock(this)) {
        "24" -> true
        "12" -> false
        else -> DateFormat.is24HourFormat(this)
    }

    private fun updateClock() {
        val now = Date()
        tvTime.text = SimpleDateFormat(if (is24h()) "HH:mm" else "h:mm", Locale.getDefault()).format(now)
        val pat = DateFormat.getBestDateTimePattern(Locale.getDefault(), "EEEEdMMMM")
        tvDate.text = SimpleDateFormat(pat, Locale.getDefault()).format(now)
            .replaceFirstChar { it.uppercase() }
    }

    private fun updateTimer() {
        val rem = Player.remainingMs()
        if (rem >= 0 && Player.isPlaying()) {
            tvTimer.text = Ui.fmtCountdown(rem)
            tvTimer.visibility = View.VISIBLE
        } else {
            tvTimer.visibility = View.GONE
        }
    }

    private fun useFahrenheit(): Boolean = when (Prefs.units(this)) {
        "f" -> true
        "c" -> false
        else -> Locale.getDefault().country in setOf("US", "LR", "MM", "BS", "BZ", "KY", "PW")
    }

    private fun loadWeather() {
        if (Prefs.weatherMode(this) == "off") {
            tvWeather.visibility = View.GONE
            return
        }
        Weather.get(this) { info ->
            weather = info
            if (isDestroyed) return@get
            if (info == null) {
                tvWeather.visibility = View.GONE
            } else {
                val f = useFahrenheit()
                val t = if (f) info.tempC * 9.0 / 5.0 + 32.0 else info.tempC
                tvWeather.text = "%s %d°%s · %s".format(
                    info.emoji(), t.roundToInt(), if (f) "F" else "C", getString(info.labelRes())
                )
                tvWeather.visibility = View.VISIBLE
            }
        }
    }
}
